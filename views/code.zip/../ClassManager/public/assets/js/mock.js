function fill_add_user() {
    $("#user_level").val("1");
    $("#tele_id").val("1234");
    $("#tele_user").val("qua");
    $("#address").val("123 TC");
    $("#social").val("fb.com");
    $("#phone").val("034888");
    $("#full_name").val("Nguyen Van C");
}