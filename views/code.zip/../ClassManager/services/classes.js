'use strict';
const Classes = require('../models').Classes;
module.exports = {
    Classes,
};