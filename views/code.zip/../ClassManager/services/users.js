'use strict';
const Users = require('../models').Users;
module.exports = {};